/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica7_grupo;

/**
 *
 * @author ausias
 */
public class Practica7_Grupo {

    public static void PrintReverseString(String frase) {
        String frase_revertida = "";
        for (int i = (frase.length() - 1); i >= 0; i--) {
            frase_revertida = frase_revertida + frase.charAt(i);
        }
        System.out.println(frase_revertida);
    }

    public static void Dau() {
        final int MAX = 6, MIN = 1;
        int numero_aleatori = (int) (Math.random() * (MAX - MIN + 1) + MIN);
        System.out.println(numero_aleatori);
    }

    public static void main(String[] args) {
        String frase = "Hola como estás?";
        PrintReverseString(frase);
        Dau();
    }
}
